public class VerticalTakeOff implements TakeOffType {
 
	@Override
	public void doTakeOff() {
	 
		System.out.println("Vertical");
	}
	 
}