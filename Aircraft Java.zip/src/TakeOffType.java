public interface TakeOffType {
 
	public abstract void doTakeOff();
}
 