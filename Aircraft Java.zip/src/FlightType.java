public interface FlightType {
 
	public abstract void doFlight();
}