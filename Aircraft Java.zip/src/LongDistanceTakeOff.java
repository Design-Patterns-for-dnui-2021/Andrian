public class LongDistanceTakeOff implements TakeOffType {
 
	@Override
	public void doTakeOff() {
	 
		System.out.println("Long Distance");
	}
	 
}