public class SuperSonicFly implements FlightType {
 
	@Override
	public void doFlight() {
	 
		System.out.println("Super Sonic");
	}
	 
}