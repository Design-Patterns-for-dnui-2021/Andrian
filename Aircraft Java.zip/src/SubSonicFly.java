public class SubSonicFly implements FlightType {
 
	@Override
	public void doFlight() {
	 
		System.out.println("Sub Sonic Flight");
	}
	 
}